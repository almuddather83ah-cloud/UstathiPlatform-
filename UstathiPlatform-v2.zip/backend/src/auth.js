import crypto from 'node:crypto';

const SECRET = process.env.JWT_SECRET || 'development-only-change-me';
const TTL_SECONDS = 60 * 60 * 24 * 7;

export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}
export function verifyPassword(password, hash, salt) {
  const actual = Buffer.from(hashPassword(password, salt).hash, 'hex');
  const expected = Buffer.from(hash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}
function b64(obj) { return Buffer.from(JSON.stringify(obj)).toString('base64url'); }
function sign(data) { return crypto.createHmac('sha256', SECRET).update(data).digest('base64url'); }
export function createToken(user) {
  const payload = { sub: user.id, role: user.role, name: user.name, iat: Math.floor(Date.now()/1000), exp: Math.floor(Date.now()/1000) + TTL_SECONDS };
  const head = b64({ alg: 'HS256', typ: 'JWT' });
  const body = b64(payload);
  return `${head}.${body}.${sign(`${head}.${body}`)}`;
}
export function authenticate(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  const token = header.slice(7);
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h,p,s] = parts;
  const expected = sign(`${h}.${p}`);
  if (s.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected))) return null;
  try {
    const payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
    if (!payload.sub || payload.exp < Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}
