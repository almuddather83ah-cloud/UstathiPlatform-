import http from 'node:http';
import { URL } from 'node:url';
import { mkdirSync, writeFileSync, unlinkSync, existsSync } from 'node:fs';
import path from 'node:path';
import { db } from './db.js';
import { authenticate, createToken, hashPassword, verifyPassword } from './auth.js';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const TEACHER_CODE = process.env.TEACHER_INVITE_CODE || 'USTATHI-TEACHER-2026';
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './data/uploads');
mkdirSync(UPLOAD_DIR, { recursive: true });

const send = (res, status, data, extraHeaders={}) => {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    ...extraHeaders
  });
  res.end(JSON.stringify(data));
};
const readJson = req => new Promise((resolve, reject) => {
  let body='';
  req.on('data', c => { body += c; if (body.length > 8_000_000) req.destroy(); });
  req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('JSON غير صالح')); } });
  req.on('error', reject);
});
const requireAuth = (req,res) => { const u=authenticate(req); if(!u){send(res,401,{error:'سجّل الدخول أولًا.'});return null;} return u; };
const requireTeacher = (req,res) => { const u=requireAuth(req,res); if(!u)return null; if(u.role!=='teacher'){send(res,403,{error:'هذه العملية للمعلم فقط.'});return null;} return u; };
const publicUser = r => ({id:r.id,name:r.name,email:r.email,role:r.role,createdAt:r.created_at});
const courseSummary = c => ({id:c.id,stage:c.stage,subject:c.subject,title:c.title,description:c.description,teacherId:c.teacher_id,teacherName:c.teacher_name||null,lessons:Number(c.lessons||0),quizzes:Number(c.quizzes||0),students:Number(c.students||0),createdAt:c.created_at});
function getCourses(){return db.prepare(`SELECT c.*,u.name teacher_name,COUNT(DISTINCT l.id) lessons,COUNT(DISTINCT q.id) quizzes,COUNT(DISTINCT e.id) students FROM courses c LEFT JOIN users u ON u.id=c.teacher_id LEFT JOIN lessons l ON l.course_id=c.id LEFT JOIN quizzes q ON q.course_id=c.id LEFT JOIN enrollments e ON e.course_id=c.id GROUP BY c.id ORDER BY c.id DESC`).all().map(courseSummary)}
function getCourse(id){
  const c=db.prepare(`SELECT c.*,u.name teacher_name FROM courses c LEFT JOIN users u ON u.id=c.teacher_id WHERE c.id=?`).get(id); if(!c)return null;
  const lessons=db.prepare(`SELECT id,title,video,lesson_order orderNo FROM lessons WHERE course_id=? ORDER BY lesson_order,id`).all(id).map(l=>({id:l.id,title:l.title,order:l.orderNo,video:l.video||null,materials:db.prepare(`SELECT id,title,url FROM materials WHERE lesson_id=? ORDER BY id`).all(l.id)}));
  const quizzes=db.prepare(`SELECT id,title FROM quizzes WHERE course_id=? ORDER BY id`).all(id).map(q=>({id:q.id,title:q.title,questions:db.prepare(`SELECT id,text,options_json,answer FROM questions WHERE quiz_id=? ORDER BY id`).all(q.id).map(x=>({id:x.id,text:x.text,options:JSON.parse(x.options_json),answer:x.answer}))}));
  return {id:c.id,stage:c.stage,subject:c.subject,title:c.title,description:c.description,teacherId:c.teacher_id,teacherName:c.teacher_name||null,lessons,quizzes};
}
function ownsCourse(u,id){const c=db.prepare('SELECT * FROM courses WHERE id=?').get(id); if(!c)return null; if(c.teacher_id!==null && Number(c.teacher_id)!==Number(u.sub))return false; return c;}
function ownsLesson(u,id){const l=db.prepare('SELECT l.*,c.teacher_id FROM lessons l JOIN courses c ON c.id=l.course_id WHERE l.id=?').get(id); if(!l)return null; if(l.teacher_id!==null&&Number(l.teacher_id)!==Number(u.sub))return false; return l;}
function ownsQuiz(u,id){const q=db.prepare('SELECT q.*,c.teacher_id FROM quizzes q JOIN courses c ON c.id=q.course_id WHERE q.id=?').get(id); if(!q)return null; if(q.teacher_id!==null&&Number(q.teacher_id)!==Number(u.sub))return false; return q;}
function safeFileName(name){return String(name||'file').replace(/[^a-zA-Z0-9._-]/g,'_').slice(-100)||'file';}

async function route(req,res){
  if(req.method==='OPTIONS')return send(res,204,{});
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`); const pathName=url.pathname;
  if(req.method==='GET'&&pathName==='/api/health')return send(res,200,{ok:true,service:'ustathi-api',time:new Date().toISOString()});

  if(req.method==='POST'&&(pathName==='/api/register'||pathName==='/api/register/teacher')){
    const b=await readJson(req); const role=pathName.endsWith('/teacher')?'teacher':(b.role||'student');
    if(!['student','teacher'].includes(role))return send(res,400,{error:'الدور غير صالح.'});
    if(!b.name?.trim()||!b.email?.trim()||!b.password||b.password.length<6)return send(res,400,{error:'أدخل الاسم والبريد وكلمة مرور لا تقل عن 6 أحرف.'});
    if(role==='teacher'&&b.teacherInviteCode!==TEACHER_CODE)return send(res,403,{error:'رمز دعوة المعلم غير صحيح.'});
    const {hash,salt}=hashPassword(b.password);
    try{const r=db.prepare(`INSERT INTO users(name,email,password_hash,password_salt,role) VALUES(?,?,?,?,?)`).run(b.name.trim(),b.email.trim().toLowerCase(),hash,salt,role);const user=db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid));return send(res,201,{user:publicUser(user),token:createToken(user)})}catch(e){if(String(e.message).includes('UNIQUE'))return send(res,409,{error:'البريد الإلكتروني مستخدم بالفعل.'});throw e}
  }
  if(req.method==='POST'&&pathName==='/api/login'){
    const b=await readJson(req);const u=db.prepare('SELECT * FROM users WHERE email=?').get((b.email||'').trim().toLowerCase());
    if(!u||!verifyPassword(b.password||'',u.password_hash,u.password_salt))return send(res,401,{error:'البريد الإلكتروني أو كلمة المرور غير صحيحة.'});return send(res,200,{user:publicUser(u),token:createToken(u)});
  }
  if(req.method==='GET'&&pathName==='/api/courses')return send(res,200,getCourses());
  const courseMatch=pathName.match(/^\/api\/courses\/(\d+)$/);
  if(req.method==='GET'&&courseMatch){const c=getCourse(Number(courseMatch[1]));return c?send(res,200,c):send(res,404,{error:'الدورة غير موجودة.'});}
  if(req.method==='POST'&&pathName==='/api/enroll'){const u=requireAuth(req,res);if(!u)return;const b=await readJson(req),courseId=Number(b.courseId);if(!getCourse(courseId))return send(res,404,{error:'الدورة غير موجودة.'});try{db.prepare('INSERT INTO enrollments(user_id,course_id) VALUES(?,?)').run(u.sub,courseId);db.prepare('INSERT OR IGNORE INTO progress(user_id,course_id) VALUES(?,?)').run(u.sub,courseId);return send(res,201,{ok:true,message:'تم تسجيلك في الدورة بنجاح.'})}catch(e){if(String(e.message).includes('UNIQUE'))return send(res,409,{error:'أنت مسجل بالفعل في هذه الدورة.'});throw e}}
  const dashMatch=pathName.match(/^\/api\/dashboard\/(\d+)$/);
  if(req.method==='GET'&&dashMatch){const u=requireAuth(req,res);if(!u)return;const requested=Number(dashMatch[1]);if(Number(u.sub)!==requested&&u.role!=='teacher')return send(res,403,{error:'غير مصرح.'});if(u.role==='teacher')return send(res,200,{role:'teacher',students:Number(db.prepare(`SELECT COUNT(*) n FROM users WHERE role='student'`).get().n),courses:Number(db.prepare('SELECT COUNT(*) n FROM courses').get().n),lessons:Number(db.prepare('SELECT COUNT(*) n FROM lessons').get().n),quizzes:Number(db.prepare('SELECT COUNT(*) n FROM quizzes').get().n)});const rows=db.prepare(`SELECT p.course_id courseId,p.completed_lessons completedLessons,p.quiz_score quizScore,c.* FROM progress p JOIN courses c ON c.id=p.course_id WHERE p.user_id=? ORDER BY c.id DESC`).all(u.sub);return send(res,200,{role:'student',courses:rows.map(x=>({courseId:x.courseId,completedLessons:x.completedLessons,quizScore:x.quizScore,course:courseSummary({...x,lessons:db.prepare('SELECT COUNT(*) n FROM lessons WHERE course_id=?').get(x.courseId).n,quizzes:db.prepare('SELECT COUNT(*) n FROM quizzes WHERE course_id=?').get(x.courseId).n})}))});}
  if(req.method==='POST'&&pathName==='/api/progress'){const u=requireAuth(req,res);if(!u)return;const b=await readJson(req),courseId=Number(b.courseId);if(!db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(u.sub,courseId))return send(res,403,{error:'يجب الالتحاق بالدورة أولًا.'});const max=db.prepare('SELECT COUNT(*) n FROM lessons WHERE course_id=?').get(courseId).n;const completed=Math.max(0,Math.min(Number(b.completedLessons||0),Number(max)));db.prepare(`INSERT INTO progress(user_id,course_id,completed_lessons,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,course_id) DO UPDATE SET completed_lessons=excluded.completed_lessons,updated_at=CURRENT_TIMESTAMP`).run(u.sub,courseId,completed);return send(res,200,{ok:true,completedLessons:completed});}

  // Teacher course CRUD
  if(req.method==='POST'&&pathName==='/api/courses'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req);if(!['middle','secondary'].includes(b.stage)||!b.subject?.trim()||!b.title?.trim())return send(res,400,{error:'المرحلة والمادة واسم الدورة مطلوبة.'});const r=db.prepare('INSERT INTO courses(stage,subject,title,description,teacher_id) VALUES(?,?,?,?,?)').run(b.stage,b.subject.trim(),b.title.trim(),b.description?.trim()||'',u.sub);return send(res,201,getCourse(Number(r.lastInsertRowid)));}
  if((req.method==='PUT'||req.method==='PATCH')&&courseMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(courseMatch[1]);const c=ownsCourse(u,id);if(c===null)return send(res,404,{error:'الدورة غير موجودة.'});if(c===false)return send(res,403,{error:'لا يمكنك تعديل دورة معلم آخر.'});const b=await readJson(req);const stage=b.stage??c.stage,subject=(b.subject??c.subject).trim(),title=(b.title??c.title).trim(),description=(b.description??c.description).trim();if(!['middle','secondary'].includes(stage)||!subject||!title)return send(res,400,{error:'المرحلة والمادة واسم الدورة مطلوبة.'});db.prepare('UPDATE courses SET stage=?,subject=?,title=?,description=? WHERE id=?').run(stage,subject,title,description,id);return send(res,200,getCourse(id));}
  if(req.method==='DELETE'&&courseMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(courseMatch[1]);const c=ownsCourse(u,id);if(c===null)return send(res,404,{error:'الدورة غير موجودة.'});if(c===false)return send(res,403,{error:'لا يمكنك حذف دورة معلم آخر.'});db.prepare('DELETE FROM courses WHERE id=?').run(id);return send(res,200,{ok:true});}

  // Lessons
  if(req.method==='POST'&&pathName==='/api/lessons'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req),courseId=Number(b.courseId),c=ownsCourse(u,courseId);if(!c)return send(res,c===null?404:403,{error:c===null?'الدورة غير موجودة.':'لا يمكنك تعديل دورة معلم آخر.'});if(!b.title?.trim())return send(res,400,{error:'عنوان الدرس مطلوب.'});const order=Number(db.prepare('SELECT COALESCE(MAX(lesson_order),0)+1 n FROM lessons WHERE course_id=?').get(courseId).n);const r=db.prepare('INSERT INTO lessons(course_id,title,video,lesson_order) VALUES(?,?,?,?)').run(courseId,b.title.trim(),b.video?.trim()||null,order);return send(res,201,getCourse(courseId).lessons.find(x=>x.id===Number(r.lastInsertRowid)));}
  const lessonMatch=pathName.match(/^\/api\/lessons\/(\d+)$/);
  if((req.method==='PUT'||req.method==='PATCH')&&lessonMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(lessonMatch[1]),l=ownsLesson(u,id);if(!l)return send(res,l===null?404:403,{error:l===null?'الدرس غير موجود.':'لا يمكنك تعديل هذا الدرس.'});const b=await readJson(req);const title=(b.title??l.title).trim();if(!title)return send(res,400,{error:'عنوان الدرس مطلوب.'});db.prepare('UPDATE lessons SET title=?,video=?,lesson_order=? WHERE id=?').run(title,b.video===undefined?l.video:(b.video?.trim()||null),b.order===undefined?l.lesson_order:Number(b.order),id);return send(res,200,{ok:true,id,title,order:Number(b.order===undefined?l.lesson_order:b.order),video:b.video===undefined?l.video:(b.video?.trim()||null),materials:db.prepare('SELECT id,title,url FROM materials WHERE lesson_id=? ORDER BY id').all(id)});}
  if(req.method==='DELETE'&&lessonMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(lessonMatch[1]),l=ownsLesson(u,id);if(!l)return send(res,l===null?404:403,{error:l===null?'الدرس غير موجود.':'لا يمكنك حذف هذا الدرس.'});db.prepare('DELETE FROM lessons WHERE id=?').run(id);return send(res,200,{ok:true});}

  // Materials
  if(req.method==='POST'&&pathName==='/api/materials'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req),lessonId=Number(b.lessonId),l=ownsLesson(u,lessonId);if(!l)return send(res,l===null?404:403,{error:l===null?'الدرس غير موجود.':'لا يمكنك تعديل هذا الدرس.'});if(!b.title?.trim()||!b.url?.trim())return send(res,400,{error:'عنوان ورابط المادة مطلوبان.'});const r=db.prepare('INSERT INTO materials(lesson_id,title,url) VALUES(?,?,?)').run(lessonId,b.title.trim(),b.url.trim());return send(res,201,{id:Number(r.lastInsertRowid),title:b.title.trim(),url:b.url.trim()});}
  const materialMatch=pathName.match(/^\/api\/materials\/(\d+)$/);
  if(req.method==='DELETE'&&materialMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(materialMatch[1]);const m=db.prepare('SELECT m.*,l.id lesson_id,c.teacher_id FROM materials m JOIN lessons l ON l.id=m.lesson_id JOIN courses c ON c.id=l.course_id WHERE m.id=?').get(id);if(!m)return send(res,404,{error:'المادة غير موجودة.'});if(m.teacher_id!==null&&Number(m.teacher_id)!==Number(u.sub))return send(res,403,{error:'غير مصرح.'});db.prepare('DELETE FROM materials WHERE id=?').run(id);return send(res,200,{ok:true});}

  // Quizzes and questions
  if(req.method==='POST'&&pathName==='/api/quizzes'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req),courseId=Number(b.courseId),c=ownsCourse(u,courseId);if(!c)return send(res,c===null?404:403,{error:c===null?'الدورة غير موجودة.':'لا يمكنك تعديل دورة معلم آخر.'});if(!b.title?.trim())return send(res,400,{error:'عنوان الاختبار مطلوب.'});const r=db.prepare('INSERT INTO quizzes(course_id,title) VALUES(?,?)').run(courseId,b.title.trim());return send(res,201,getCourse(courseId).quizzes.find(x=>x.id===Number(r.lastInsertRowid)));}
  const quizMatch=pathName.match(/^\/api\/quizzes\/(\d+)$/);
  if((req.method==='PUT'||req.method==='PATCH')&&quizMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(quizMatch[1]),q=ownsQuiz(u,id);if(!q)return send(res,q===null?404:403,{error:q===null?'الاختبار غير موجود.':'غير مصرح.'});const b=await readJson(req);if(!b.title?.trim())return send(res,400,{error:'عنوان الاختبار مطلوب.'});db.prepare('UPDATE quizzes SET title=? WHERE id=?').run(b.title.trim(),id);return send(res,200,{id,title:b.title.trim()});}
  if(req.method==='DELETE'&&quizMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(quizMatch[1]),q=ownsQuiz(u,id);if(!q)return send(res,q===null?404:403,{error:q===null?'الاختبار غير موجود.':'غير مصرح.'});db.prepare('DELETE FROM quizzes WHERE id=?').run(id);return send(res,200,{ok:true});}
  if(req.method==='POST'&&pathName==='/api/questions'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req),quizId=Number(b.quizId),q=ownsQuiz(u,quizId);if(!q)return send(res,q===null?404:403,{error:q===null?'الاختبار غير موجود.':'غير مصرح.'});if(!b.text?.trim()||!Array.isArray(b.options)||b.options.length<2||!Number.isInteger(Number(b.answer)))return send(res,400,{error:'السؤال والخيارات والإجابة الصحيحة مطلوبة.'});const answer=Number(b.answer);if(answer<0||answer>=b.options.length)return send(res,400,{error:'رقم الإجابة غير صالح.'});const r=db.prepare('INSERT INTO questions(quiz_id,text,options_json,answer) VALUES(?,?,?,?)').run(quizId,b.text.trim(),JSON.stringify(b.options.map(String)),answer);return send(res,201,{id:Number(r.lastInsertRowid),text:b.text.trim(),options:b.options.map(String),answer});}
  const questionMatch=pathName.match(/^\/api\/questions\/(\d+)$/);
  if(req.method==='DELETE'&&questionMatch){const u=requireTeacher(req,res);if(!u)return;const id=Number(questionMatch[1]),q=db.prepare('SELECT qu.*,c.teacher_id FROM questions q JOIN quizzes qu ON qu.id=q.quiz_id JOIN courses c ON c.id=qu.course_id WHERE q.id=?').get(id);if(!q)return send(res,404,{error:'السؤال غير موجود.'});if(q.teacher_id!==null&&Number(q.teacher_id)!==Number(u.sub))return send(res,403,{error:'غير مصرح.'});db.prepare('DELETE FROM questions WHERE id=?').run(id);return send(res,200,{ok:true});}

  // Teacher dashboard data
  if(req.method==='GET'&&pathName==='/api/admin/overview'){const u=requireTeacher(req,res);if(!u)return;const students=db.prepare(`SELECT COUNT(*) n FROM users WHERE role='student'`).get().n;const teachers=db.prepare(`SELECT COUNT(*) n FROM users WHERE role='teacher'`).get().n;const courses=db.prepare('SELECT COUNT(*) n FROM courses').get().n;const lessons=db.prepare('SELECT COUNT(*) n FROM lessons').get().n;const quizzes=db.prepare('SELECT COUNT(*) n FROM quizzes').get().n;const enrollments=db.prepare('SELECT COUNT(*) n FROM enrollments').get().n;const recent=db.prepare(`SELECT e.id,e.enrolled_at,u.name student_name,c.title course_title FROM enrollments e JOIN users u ON u.id=e.user_id JOIN courses c ON c.id=e.course_id ORDER BY e.id DESC LIMIT 8`).all();return send(res,200,{students:Number(students),teachers:Number(teachers),courses:Number(courses),lessons:Number(lessons),quizzes:Number(quizzes),enrollments:Number(enrollments),recent});}
  if(req.method==='GET'&&pathName==='/api/students'){const u=requireTeacher(req,res);if(!u)return;const students=db.prepare(`SELECT id,name,email,created_at FROM users WHERE role='student' ORDER BY name`).all().map(s=>({...publicUser({...s,role:'student'}),enrollments:db.prepare(`SELECT e.course_id,c.title FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.user_id=? ORDER BY e.id DESC`).all(s.id)}));return send(res,200,students);}

  // Simple authenticated file upload using base64 JSON. Intended for PDF/audio/video links/files with modest sizes.
  if(req.method==='POST'&&pathName==='/api/uploads'){const u=requireTeacher(req,res);if(!u)return;const b=await readJson(req);if(!b.name||!b.data||typeof b.data!=='string')return send(res,400,{error:'اسم الملف والبيانات مطلوبة.'});if(b.data.length>12_000_000)return send(res,413,{error:'الملف كبير جدًا. استخدم رابطًا خارجيًا أو ملفًا أصغر.'});const safe=safeFileName(b.name);const ext=path.extname(safe).toLowerCase();const allowed=['.pdf','.mp4','.webm','.mp3','.m4a','.jpg','.jpeg','.png'];if(!allowed.includes(ext))return send(res,400,{error:'نوع الملف غير مدعوم.'});const raw=b.data.replace(/^data:[^;]+;base64,/,'');const fileName=`${Date.now()}-${Math.random().toString(36).slice(2,8)}${ext}`;const full=path.join(UPLOAD_DIR,fileName);writeFileSync(full,Buffer.from(raw,'base64'));const base=process.env.PUBLIC_BASE_URL||`http://localhost:${PORT}`;return send(res,201,{url:`${base}/uploads/${fileName}`,name:safe,size:Buffer.byteLength(Buffer.from(raw,'base64'))});}
  if(req.method==='GET'&&pathName.startsWith('/uploads/')){const name=safeFileName(pathName.slice('/uploads/'.length));const full=path.join(UPLOAD_DIR,name);if(!existsSync(full))return send(res,404,{error:'الملف غير موجود.'});res.writeHead(200,{'Access-Control-Allow-Origin':process.env.CORS_ORIGIN||'*','Content-Type':name.endsWith('.pdf')?'application/pdf':'application/octet-stream'});return res.end(require('node:fs').readFileSync(full));}
  return send(res,404,{error:'المسار غير موجود.'});
}
const server=http.createServer((req,res)=>route(req,res).catch(e=>{console.error(e);if(!res.headersSent)send(res,500,{error:'حدث خطأ داخلي في الخادم.'})}));
server.listen(PORT,HOST,()=>console.log(`Ustathi API running on http://${HOST}:${PORT}`));
