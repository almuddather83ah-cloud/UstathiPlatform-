import { db } from '../src/db.js';
import { hashPassword } from '../src/auth.js';

const teacherEmail='teacher@ustathi.local';
let teacher=db.prepare(`SELECT * FROM users WHERE email=?`).get(teacherEmail);
if(!teacher){
  const {hash,salt}=hashPassword('Teacher@12345');
  const r=db.prepare(`INSERT INTO users(name,email,password_hash,password_salt,role) VALUES(?,?,?,?,?)`).run('معلم أستاذي',teacherEmail,hash,salt,'teacher');
  teacher=db.prepare(`SELECT * FROM users WHERE id=?`).get(Number(r.lastInsertRowid));
}
const count=db.prepare(`SELECT COUNT(*) n FROM courses`).get().n;
if(count===0){
  const courses=[
    ['middle','الرياضيات','الدالة (التطبيق)','شرح مبسط وتدريبات للمرحلة المتوسطة'],
    ['middle','العلوم','العلوم الطبيعية','مراجعة ودروس واختبارات العلوم'],
    ['secondary','الأحياء','مفاهيم علم الوراثة','مدخل إلى علم الوراثة وتطبيقاته'],
    ['secondary','الرياضيات','التفاضل والتكامل','مسار تدريجي في النهايات والمشتقات والتكامل']
  ];
  const insertC=db.prepare(`INSERT INTO courses(stage,subject,title,description,teacher_id) VALUES(?,?,?,?,?)`);
  const insertL=db.prepare(`INSERT INTO lessons(course_id,title,video,lesson_order) VALUES(?,?,?,?)`);
  const insertQ=db.prepare(`INSERT INTO quizzes(course_id,title) VALUES(?,?)`);
  const insertQuestion=db.prepare(`INSERT INTO questions(quiz_id,text,options_json,answer) VALUES(?,?,?,?)`);
  for(const c of courses){
    const id=Number(insertC.run(...c,teacher.id).lastInsertRowid);
    insertL.run(id,'الدرس الأول',null,1);
    insertL.run(id,'الدرس الثاني',null,2);
    const qid=Number(insertQ.run(id,'اختبار قصير').lastInsertRowid);
    insertQuestion.run(qid,'اختر الإجابة الصحيحة',JSON.stringify(['أ','ب','ج','د']),1);
  }
}
console.log('تم تجهيز قاعدة البيانات والبيانات التجريبية.');
console.log('Teacher: teacher@ustathi.local / Teacher@12345');
